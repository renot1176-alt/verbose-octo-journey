# Catatan implementasi desain

Dua gambar di folder ini adalah referensi visual yang diberikan untuk proyek BiruFinance. Keduanya hanya disertakan sebagai dokumentasi sumber dan tidak dimuat sebagai aset runtime APK.

## Dashboard
- Mempertahankan identitas biru terang dan lapisan kaca transparan.
- Logo dan nama merek diletakkan di bagian atas.
- Saldo dan tabungan dibuat menonjol; pemasukan dan pengeluaran ditampilkan sebagai dua kartu berdampingan.
- Aksi cepat menggunakan tiga tombol utama.
- Navigasi bawah berisi Ringkasan, Transaksi, Anggaran, Tabungan, dan Laporan.
- Transaksi terbaru serta ringkasan anggaran berada di dashboard.

## Ikon
- Ikon launcher menggunakan simbol berlian biru dari referensi ikon.
- File ikon launcher dipangkas ke area tile utama dan dibuat ulang untuk density Android mdpi sampai xxxhdpi.

## Batasan
Desain mengambil bahasa visual dan susunan komponen dari referensi, bukan menyalin screenshot sebagai layar statis. Semua nominal dan daftar pada aplikasi berasal dari data lokal pengguna.
