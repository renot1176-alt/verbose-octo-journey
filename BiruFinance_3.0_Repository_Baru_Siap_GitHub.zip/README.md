# BiruFinance 3.0 — Repository Siap GitHub

Repository ini sudah disusun dengan struktur Gradle di **root repository**. Tidak perlu folder `project/` atau ekstrak ZIP source lain di dalam workflow.

## Cara membuat repository baru

1. Buat repository baru di GitHub, misalnya `BiruFinance`.
2. Pilih **Public** atau **Private** sesuai keinginan. Tidak perlu menambahkan README, `.gitignore`, atau License saat membuat repository.
3. Ekstrak ZIP ini di perangkat.
4. Upload **seluruh isi folder hasil ekstrak** langsung ke halaman utama repository. Jangan upload folder induk `BiruFinance_Repo_Baru` sebagai satu folder bertingkat.
5. Pastikan folder tersembunyi `.github/workflows/build-apk.yml` ikut terupload. Jika memakai GitHub web di HP dan folder tersembunyi tidak terlihat, aktifkan tampilan file tersembunyi atau gunakan GitHub Desktop / git.
6. Commit perubahan ke branch `main`.
7. Buka tab **Actions** → **Build BiruFinance APK** → **Run workflow**.
8. Setelah selesai dengan status hijau, buka hasil run dan unduh artifact `BiruFinance-3.0.0-debug-APK`.

## Struktur root yang wajib terlihat di GitHub

```text
.github/
  workflows/
    build-apk.yml
app/
build.gradle
gradle.properties
settings.gradle
README.md
```

Workflow akan menjalankan `gradle assembleDebug` dari root repository dan mengunggah APK debug.

## Catatan
- Ini adalah APK debug untuk uji coba, belum APK release bertanda tangan untuk publikasi Play Store.
- Build belum dinyatakan berhasil sampai workflow selesai hijau.
- Aplikasi menyimpan data secara lokal pada perangkat; jangan menghapus data aplikasi sebelum membuat backup.


---

# Biru Finance 3.0 — Liquid Glass Offline

Pengembangan lanjutan dari ZIP BiruFinance_Source.zip dengan fondasi Android WebView yang sudah ada. Antarmuka dibuat ulang lebih dekat dengan referensi dashboard Biru Finance: identitas berlian biru, kartu kaca transparan, ringkasan saldo/tabungan, kartu pemasukan-pengeluaran, aksi cepat, navigasi bawah, transaksi terbaru, dan anggaran.

## Fitur 3.0
- Dashboard Liquid Glass biru dengan splash animation dan soundtrack pembuka.
- Saldo dompet total, total tabungan target, pemasukan dan pengeluaran bulan berjalan.
- Pencatatan pemasukan/pengeluaran dengan kategori, dompet, catatan, tanggal, edit, hapus, dan pencarian.
- Multi-dompet dan transfer saldo dengan riwayat transfer.
- Anggaran bulanan per kategori, edit batas, progres, sisa, dan peringatan ketika melewati batas.
- Target tabungan dengan kontribusi dan progres.
- Laporan pemasukan/pengeluaran, selisih bersih, grafik enam bulan, dan kategori pengeluaran.
- Kalkulator dengan operasi dasar, persentase, riwayat, dan memasukkan hasil ke form transaksi.
- Backup/pemulihan JSON, ekspor CSV, sembunyikan nominal, efek suara, dan getaran.
- Navigasi bawah serta swipe antarhalaman.
- Pemilih file Android untuk memulihkan backup dan penyimpanan ekspor langsung ke folder Download pada Android 10+.
- Data tetap lokal/offline; tidak ada login, API, atau server.

## Menyiapkan APK lewat GitHub (gratis)
1. Ekstrak ZIP ini.
2. Buat repository GitHub baru atau gunakan repository proyek BiruFinance.
3. Upload **seluruh isi folder `BiruFinance_Ultimate`** ke root repository, termasuk folder tersembunyi `.github/workflows`.
4. Buka tab **Actions**. Jalankan workflow **Build BiruFinance APK** melalui **Run workflow**, atau push ke branch `main`/`master`.
5. Setelah workflow berhasil, buka hasil run dan unduh artifact **BiruFinance-3.0.0-debug-APK**.
6. Ekstrak artifact tersebut, lalu pasang `app-debug.apk` di Android.

Workflow menyiapkan Java 17, Gradle 8.9, Android SDK Platform 35, dan Build Tools 35.0.0. Android Gradle Plugin 8.7.3 digunakan untuk proses build.

## Catatan teknis dan batasan
- Ini APK debug untuk pengujian/pemasangan pribadi, bukan APK release Play Store yang ditandatangani dengan kunci rilis.
- Antarmuka berjalan di WebView lokal. Penyimpanan utama menggunakan `localStorage`, bukan SQLite. Data bisa hilang jika data aplikasi dibersihkan atau aplikasi dihapus; buat backup JSON berkala.
- Migrasi otomatis disediakan dari format data BiruFinance versi awal yang memakai key `biru-finance-complete-v2` dan dari key Ultimate 2.0.
- Transfer antar-dompet mengubah saldo antar dompet dan tidak dihitung sebagai pemasukan/pengeluaran.
- Setoran target tabungan dicatat sebagai progres target dan tidak memindahkan saldo dompet secara otomatis.
- Kalkulator mendukung operasi aritmetika dasar dan persentase, bukan kalkulator ilmiah.
- Ukuran APK akhir ditentukan oleh hasil build Android; source ZIP tidak ditambah file kosong hanya untuk mengejar ukuran tertentu.
- Build belum dinyatakan berhasil sampai GitHub Actions selesai dengan status hijau dan APK diuji di perangkat.

## Struktur utama
- `app/src/main/assets/index.html`: halaman dan komponen aplikasi.
- `app/src/main/assets/style.css`: tema Liquid Glass.
- `app/src/main/assets/app.js`: logika transaksi, dompet, anggaran, tabungan, laporan, kalkulator, backup, dan migrasi.
- `app/src/main/assets/intro_soundtrack.wav`: soundtrack pembuka.
- `app/src/main/java/com/birufinance/app/MainActivity.java`: WebView, pemilih file, ekspor file, dan share bridge.
- `app/src/main/res/mipmap-*/ic_launcher.png`: ikon berlian biru.
- `.github/workflows/build-apk.yml`: pipeline APK otomatis.

## Privasi
Aplikasi tidak mengirim catatan keuangan ke internet. File backup berisi informasi keuangan pribadi; simpan di lokasi aman dan jangan membagikannya sembarangan.
